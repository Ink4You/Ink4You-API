package br.com.bandtec.ink4you2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ink4You2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
