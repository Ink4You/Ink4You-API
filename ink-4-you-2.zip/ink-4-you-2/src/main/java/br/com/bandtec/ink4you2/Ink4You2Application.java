package br.com.bandtec.ink4you2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ink4You2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ink4You2Application.class, args);
	}

}
