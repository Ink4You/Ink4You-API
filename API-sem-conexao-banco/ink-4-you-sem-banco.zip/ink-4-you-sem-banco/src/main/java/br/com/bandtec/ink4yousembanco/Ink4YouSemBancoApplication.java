package br.com.bandtec.ink4yousembanco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ink4YouSemBancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ink4YouSemBancoApplication.class, args);
	}

}
