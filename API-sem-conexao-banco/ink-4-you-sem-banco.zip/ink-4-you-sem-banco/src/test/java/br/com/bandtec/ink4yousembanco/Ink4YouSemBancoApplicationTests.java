package br.com.bandtec.ink4yousembanco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ink4YouSemBancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
