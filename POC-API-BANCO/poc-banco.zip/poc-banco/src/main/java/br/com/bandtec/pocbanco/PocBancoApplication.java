package br.com.bandtec.pocbanco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocBancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocBancoApplication.class, args);
	}

}
