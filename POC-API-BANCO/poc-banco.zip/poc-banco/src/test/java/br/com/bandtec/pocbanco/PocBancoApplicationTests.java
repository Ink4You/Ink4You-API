package br.com.bandtec.pocbanco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PocBancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
